"""
YapeService: Procesa reportes de Yape con idempotencia, deduplicación y auditoría.

PILARES DE IMPLEMENTACIÓN:
1. Idempotencia: operation_number único previene duplicados
2. UPSERT pattern: INSERT IGNORE o ON CONFLICT DO NOTHING
3. Transacciones: ROLLBACK si falla cualquier paso
4. Scalability: Streams para archivos grandes (no cargar todo en RAM)
5. Sanitización: Validation + XSS prevention
"""

import csv
import io
import uuid
from datetime import datetime
from decimal import Decimal
import openpyxl
import logging

from app.models import YapeTransaction, Expense, db
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

logger = logging.getLogger(__name__)


class YapeService:
    """
    Service para procesar transacciones de Yape/Plin desde CSV/Excel.
    Garantiza idempotencia, deduplicación y auditoría completa.
    """
    
    # Palabras clave para filtrar "gastos importantes"
    EXPENSE_KEYWORDS = ['compra', 'pago', 'factura', 'proveedor', 'servicio', 'transporte']
    EXPENSE_INDICATORS = ['salida', 'egreso', 'cargo', '-']
    
    def __init__(self):
        self.batch_id = str(uuid.uuid4())  # ID único para cada lote de importación
        self.stats = {
            'total_rows': 0,
            'processed': 0,
            'duplicates_skipped': 0,
            'errors': 0,
            'expenses_created': 0
        }
    
    # =============================================================================
    # PARSER: CSV/EXCEL → Lista de diccionarios
    # =============================================================================
    
    def parse_yape_csv(self, file_stream, encoding='utf-8'):
        """
        Parsea un archivo CSV de Yape.
        Retorna un generator de diccionarios (streaming para no sobrecargar RAM).
        
        Columnas esperadas:
        - Fecha
        - Número de Operación
        - Nombre/Razón Social
        - Monto
        - Mensaje/Descripción
        """
        try:
            # Detectar si es texto o bytes
            if isinstance(file_stream, bytes):
                file_stream = io.StringIO(file_stream.decode(encoding))
            elif isinstance(file_stream, str):
                file_stream = io.StringIO(file_stream)
            
            reader = csv.DictReader(file_stream)
            
            if not reader.fieldnames:
                raise ValueError("CSV vacío o sin encabezados")
            
            for row_num, row in enumerate(reader, start=2):  # start=2 porque fila 1 es header
                try:
                    transaction = self._map_csv_row(row)
                    if transaction:
                        yield transaction
                except Exception as e:
                    logger.warning(f"Error procesando fila {row_num}: {str(e)}")
                    self.stats['errors'] += 1
        
        except Exception as e:
            logger.error(f"Error al parsear CSV: {str(e)}")
            raise ValueError(f"No se pudo leer CSV: {str(e)}")
    
    def parse_yape_excel(self, file_stream):
        """
        Parsea un archivo Excel de Yape (XLSX).
        Retorna un generator (streaming).
        """
        try:
            workbook = openpyxl.load_workbook(file_stream, read_only=True, data_only=True)
            worksheet = workbook.active
            
            # Obtener headers de la primera fila
            headers = []
            for cell in worksheet[1]:
                headers.append(cell.value)
            
            if not headers:
                raise ValueError("Excel vacío")
            
            for row_num, row in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
                try:
                    row_dict = {headers[i]: row[i] for i in range(min(len(headers), len(row)))}
                    transaction = self._map_csv_row(row_dict)
                    if transaction:
                        yield transaction
                except Exception as e:
                    logger.warning(f"Error procesando fila {row_num}: {str(e)}")
                    self.stats['errors'] += 1
        
        except Exception as e:
            logger.error(f"Error al parsear Excel: {str(e)}")
            raise ValueError(f"No se pudo leer Excel: {str(e)}")
    
    def _map_csv_row(self, row):
        """
        Mapea una fila CSV a diccionario normalizado.
        Aplica sanitización y validación.
        Flexible con múltiples formatos de Yape.
        """
        # Normalizar claves (case-insensitive, trim, etc.)
        normalized_row = {k.strip().lower(): v for k, v in row.items() if k}
        
        # Mapear columnas flexibles (Yape puede variar los nombres)
        operation_number = self._extract_field(normalized_row, [
            'número de operación', 'operation #', 'op_number', 'transaction_id',
            'id', 'referencia', 'reference', 'num_operacion'
        ])
        
        transaction_date = self._extract_field(normalized_row, [
            'fecha de operación', 'fecha', 'date', 'transaction_date', 'fecha transaccion'
        ])
        
        # Sender puede ser origen, nombre, razón social, etc.
        sender_name = self._extract_field(normalized_row, [
            'origen', 'nombre', 'razón social', 'sender', 'nombre del remitente',
            'from', 'quien', 'de', 'remitente'
        ])
        
        # Destino alternativo si no hay sobre el sender
        if not sender_name:
            sender_name = self._extract_field(normalized_row, ['destino', 'to', 'para', 'beneficiario'])
        
        amount = self._extract_field(normalized_row, ['monto', 'amount', 'cantidad', 'importe', 'valor'])
        message = self._extract_field(normalized_row, [
            'mensaje', 'description', 'nota', 'message', 'concepto',
            'tipo de transacción', 'tipo'
        ])
        
        # ✨ GENERAR operation_number si no existe ✨
        if not operation_number:
            # Crear un ID único a partir de otros campos disponibles
            origin = self._extract_field(normalized_row, ['origen', 'from', 'sender'])
            destination = self._extract_field(normalized_row, ['destino', 'to', 'para'])
            
            operation_number = f"{origin or 'SIN_ORIGEN'}_{destination or 'SIN_DESTINO'}_{str(amount or 0).replace('.', '_')}_{str(transaction_date)[:10]}"
        
        # Validaciones
        if not operation_number or not amount:
            logger.debug(f"Fila incompleta: falta operation_number o amount")
            return None
        
        # Parsear amount (puede ser string con formato monetario)
        try:
            amount = float(str(amount).replace(',', '.').replace('S/', '').strip())
        except ValueError:
            logger.warning(f"Monto inválido: {amount}")
            return None
        
        # Parsear fecha
        try:
            if isinstance(transaction_date, str):
                # Intentar múltiples formatos
                for fmt in ['%d/%m/%Y', '%Y-%m-%d', '%d-%m-%Y', '%m/%d/%Y']:
                    try:
                        transaction_date = datetime.strptime(transaction_date.strip(), fmt)
                        break
                    except ValueError:
                        continue
                else:
                    # Si ningún formato funciona, usar hoy
                    transaction_date = datetime.now()
            elif not isinstance(transaction_date, datetime):
                transaction_date = datetime.now()
        except Exception:
            logger.warning(f"Fecha inválida: {transaction_date}")
            transaction_date = datetime.now()
        
        # Sanitizar strings para XSS prevención
        operation_number = self._sanitize_string(operation_number)
        sender_name = self._sanitize_string(sender_name) or "SIN_ESPECIFICAR"
        message = self._sanitize_string(message) or ""
        
        return {
            'operation_number': operation_number,
            'transaction_date': transaction_date,
            'sender_name': sender_name,
            'amount': amount,
            'message': message
        }
    
    def _extract_field(self, row, possible_keys):
        """Busca un valor en el diccionario usando múltiples keys posibles."""
        for key in possible_keys:
            if key in row and row[key]:
                return row[key]
        return None
    
    def _sanitize_string(self, value):
        """Sanitiza string para prevenir XSS."""
        if not value:
            return None
        
        # Convertir a string y limpiar
        value = str(value).strip()
        
        # Remover caracteres peligrosos HTML/SQL basic
        dangerous_chars = ['<', '>', '"', "'", ';', '--', '/*', '*/']
        for char in dangerous_chars:
            value = value.replace(char, '')
        
        # Limitar longitud
        return value[:500] if value else None
    
    # =============================================================================
    # UPSERT: Inserción segura con deduplicación (idempotencia)
    # =============================================================================
    
    def import_transactions(self, file_stream, file_type='csv'):
        """
        Importa transacciones de Yape con UPSERT pattern (idempotencia).
        
        LÓGICA:
        1. Parser genera transacciones (streaming)
        2. Para cada transacción: verificar si operation_number existe
        3. Si NO existe: INSERT
        4. Si existe: SKIP (ya fue procesada)
        5. Si error en cualquier paso: ROLLBACK todo
        
        Retorna estadísticas de importación.
        """
        try:
            # Determinar parser según tipo de archivo
            if file_type.lower() == 'xlsx' or file_type.lower() == 'xls':
                transactions = self.parse_yape_excel(file_stream)
            else:
                transactions = self.parse_yape_csv(file_stream)
            
            batch_id = self.batch_id
            logger.info(f"Iniciando importación Yape [Batch: {batch_id}]")
            
            # Procesar transacciones en LOTE con transacción DB
            try:
                for transaction_data in transactions:
                    self.stats['total_rows'] += 1
                    
                    # Intentar insertar o ignorar si ya existe (UPSERT)
                    success = self._insert_or_ignore_transaction(transaction_data, batch_id)
                    
                    if success:
                        self.stats['processed'] += 1
                        
                        # Si es importante, crear Expense automáticamente
                        if self._is_important_expense(transaction_data):
                            self._create_expense_from_transaction(transaction_data)
                            self.stats['expenses_created'] += 1
                    else:
                        self.stats['duplicates_skipped'] += 1
                
                # COMMIT si todo salió bien
                db.session.commit()
                logger.info(f"Importación completada: {self.stats}")
                
                return True, self.stats
            
            except Exception as e:
                # ROLLBACK si algo falló
                db.session.rollback()
                logger.error(f"Error durante importación, ROLLBACK ejecutado: {str(e)}")
                self.stats['errors'] += 1
                return False, f"Error: {str(e)}"
        
        except Exception as e:
            logger.error(f"Error crítico en importación: {str(e)}")
            return False, f"Error crítico: {str(e)}"
    
    def _insert_or_ignore_transaction(self, transaction_data, batch_id):
        """
        Inserta una transacción si NO existe (UPSERT pattern).
        
        SQLAlchemy + PostgreSQL: ON CONFLICT DO NOTHING
        SQLAlchemy + MySQL: INSERT IGNORE
        SQLAlchemy + SQLite: INSERT OR IGNORE
        
        Retorna True si se insertó, False si ya existía (skip).
        """
        operation_number = transaction_data['operation_number']
        
        # Verificar si ya existe
        existing = YapeTransaction.query.filter_by(
            operation_number=operation_number
        ).first()
        
        if existing:
            logger.debug(f"Transacción {operation_number} ya existe, skipping")
            return False
        
        # Crear nueva transacción
        yape_tx = YapeTransaction(
            operation_number=operation_number,
            transaction_date=transaction_data['transaction_date'],
            sender_name=transaction_data['sender_name'],
            amount=transaction_data['amount'],
            message=transaction_data['message'],
            category=self._categorize_transaction(transaction_data),
            import_batch_id=batch_id
        )
        
        try:
            db.session.add(yape_tx)
            # No hacemos commit aquí, lo hace import_transactions al final
            logger.debug(f"Transacción {operation_number} preparada para inserción")
            return True
        except IntegrityError as e:
            # Si hay un error de integridad (duplicate), ignorar
            logger.debug(f"IntegrityError (duplicado?) {operation_number}: {str(e)}")
            db.session.rollback()
            return False
    
    def _categorize_transaction(self, transaction_data):
        """Clasifica la transacción basado en el mensaje/descripción."""
        message = (transaction_data.get('message') or '').lower()
        
        # Palabras clave para diferentes categorías
        if any(kw in message for kw in ['pago', 'salario', 'terapista']):
            return 'therapist_payment'
        elif any(kw in message for kw in ['factura', 'proveedor', 'compra', 'servicio']):
            return 'operational'
        elif any(indicator in message for indicator in self.EXPENSE_INDICATORS):
            return 'expense'
        
        return 'unclassified'
    
    def _is_important_expense(self, transaction_data):
        """Determina si es un gasto importante que debe crearse automáticamente."""
        message = (transaction_data.get('message') or '').lower()
        amount = transaction_data.get('amount', 0)
        
        # Reglas de negocio para "gastos importantes"
        # 1. Monto negativo o negación en el mensaje = salida de dinero
        is_outflow = amount < 0 or 'salida' in message or 'gasto' in message
        
        # 2. Contiene palabras clave de gasto
        has_keyword = any(kw in message for kw in self.EXPENSE_KEYWORDS)
        
        # 3. Monto mínimo (ej. > 50 soles)
        is_significant = abs(amount) > 50
        
        return (is_outflow or has_keyword) and is_significant
    
    def _create_expense_from_transaction(self, transaction_data):
        """Crea un registro Expense automáticamente desde YapeTransaction."""
        try:
            expense = Expense(
                category='operational',  # Clasificación por defecto
                amount=abs(transaction_data['amount']),  # Usar valor positivo
                date=transaction_data['transaction_date'],
                description=f"Yape: {transaction_data['sender_name']} - {transaction_data['message']}",
                method='yape_plin',
                receipt_image_path=None  # Será llenado luego via UI
            )
            db.session.add(expense)
            logger.info(f"Expense creado desde Yape: {transaction_data['operation_number']}")
        except Exception as e:
            logger.warning(f"Error creando Expense: {str(e)}")
    
    # =============================================================================
    # CONSULTAS Y BÚSQUEDAS
    # =============================================================================
    
    def get_transactions_by_batch(self, batch_id):
        """Obtiene todas las transacciones de un lote de importación."""
        return YapeTransaction.query.filter_by(import_batch_id=batch_id).all()
    
    def get_transactions_by_date_range(self, start_date, end_date):
        """Obtiene transacciones en un rango de fechas."""
        return YapeTransaction.query.filter(
            YapeTransaction.transaction_date >= start_date,
            YapeTransaction.transaction_date <= end_date
        ).order_by(YapeTransaction.transaction_date.desc()).all()
    
    def get_unattached_expenses(self, limit=50):
        """
        Obtiene transacciones Yape sin comprobante adjunto.
        Usado por UI para permitir agregar fotos.
        """
        return YapeTransaction.query.filter(
            YapeTransaction.receipt_image_path == None,
            YapeTransaction.is_expense == True
        ).order_by(YapeTransaction.transaction_date.desc()).limit(limit).all()
    
    def search_transactions(self, query, limit=20):
        """Búsqueda por operation_number, sender_name o message."""
        search_pattern = f"%{query}%"
        return YapeTransaction.query.filter(
            (YapeTransaction.operation_number.ilike(search_pattern)) |
            (YapeTransaction.sender_name.ilike(search_pattern)) |
            (YapeTransaction.message.ilike(search_pattern))
        ).limit(limit).all()
    
    # =============================================================================
    # ACTUALIZACIÓN: Adjuntar comprobante a una transacción
    # =============================================================================
    
    def attach_receipt_to_transaction(self, operation_number, receipt_path):
        """
        Adjunta una foto/comprobante a una transacción Yape existente.
        Patrón: UPDATE YapeTransaction SET receipt_image_path WHERE operation_number.
        """
        try:
            yape_tx = YapeTransaction.query.filter_by(
                operation_number=operation_number
            ).first()
            
            if not yape_tx:
                return False, "Transacción no encontrada"
            
            yape_tx.receipt_image_path = receipt_path
            yape_tx.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"Comprobante adjuntado a {operation_number}: {receipt_path}")
            return True, "Comprobante guardado exitosamente"
        
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error adjuntando comprobante: {str(e)}")
            return False, f"Error: {str(e)}"
    
    # =============================================================================
    # AUDITORÍA Y REPORTE
    # =============================================================================
    
    def get_import_stats(self):
        """Retorna estadísticas de la importación actual."""
        return self.stats
    
    def get_all_imports(self):
        """Obtiene historial de todos los lotes importados."""
        batch_ids = db.session.query(YapeTransaction.import_batch_id.distinct()).all()
        
        result = []
        for (batch_id,) in batch_ids:
            if not batch_id:
                continue
            
            batch_transactions = YapeTransaction.query.filter_by(
                import_batch_id=batch_id
            ).all()
            
            result.append({
                'batch_id': batch_id,
                'total': len(batch_transactions),
                'amount_sum': sum(t.amount for t in batch_transactions),
                'first_date': min(t.transaction_date for t in batch_transactions),
                'last_date': max(t.transaction_date for t in batch_transactions),
                'imported_at': batch_transactions[0].created_at if batch_transactions else None
            })
        
        return sorted(result, key=lambda x: x['imported_at'], reverse=True)
