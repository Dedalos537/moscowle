from flask import Blueprint, render_template, redirect, url_for, flash, current_app, request, jsonify
from flask_login import login_required, current_user
from functools import wraps
import os
from datetime import timedelta
from app.extensions import bcrypt, db
from app.models import AdminAPIToken
import secrets
from app.models import User, Appointment, SessionMetrics, db, Payment, CSPReport, Sede, ContactMessage
from app.services.dashboard_service import DashboardService
from app.services.payment_service import PaymentService
from app.services.finance_service import FinanceService
from sqlalchemy import func
from werkzeug.utils import secure_filename
import os
import uuid
from datetime import datetime
import json
from app.schemas.payment_schema import validate_payment_register

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')
dashboard_service = DashboardService()
payment_service = PaymentService()
finance_service = FinanceService()

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    overview = dashboard_service.get_admin_overview()
    
    # NEW: Financial Summary
    try:
        financials = payment_service.get_financial_summary()
    except Exception:
        financials = {'income_real': 0, 'income_expected': 0}
        
    # NEW: Sedes Breakdown
    sedes = Sede.query.filter_by(active=True).order_by(Sede.name.asc()).all()
    sedes_stats = []
    for s in sedes:
        # Count active players in this Sede
        count = User.query.filter_by(sede_id=s.id, role='jugador', is_active=True).count()
        sedes_stats.append({'id': s.id, 'name': s.name, 'count': count})
        
    # All active patients for the "Quick Pay" dropdown
    all_patients = User.query.filter_by(role='jugador', is_active=True).order_by(User.username.asc()).all()
    
    return render_template('admin/dashboard.html', 
                           overview=overview, 
                           financials=financials,
                           sedes_stats=sedes_stats,
                           all_patients=all_patients,
                           active_page='admin_dashboard')

@admin_bp.route('/users')
@login_required
def users():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    # Filtering
    sede_filter = request.args.get('sede_id')
    query = User.query
    
    if sede_filter and sede_filter.isdigit():
        query = query.filter(User.sede_id == int(sede_filter))
        
    users = query.order_by(User.created_at.desc()).all()
    
    # Pre-fetch therapist assignments for template
    patient_therapist_map = {}
    for u in users:
        if u.role == 'jugador':
            # Use the dynamic relationship to fetch IDs
            # u.therapists is a query object
            patient_therapist_map[u.id] = [t.id for t in u.therapists]
            
    therapists = User.query.filter_by(role='terapista').order_by(User.username.asc()).all()
    sedes = Sede.query.filter_by(active=True).order_by(Sede.name.asc()).all()
    
    return render_template('admin/users.html', users=users, therapists=therapists, patient_therapist_map=patient_therapist_map, sedes=sedes, active_page='admin_users')

@admin_bp.route('/games')
@login_required
def games():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    games_dir = os.path.join(current_app.root_path, 'static', 'games')
    try:
        files = [f for f in os.listdir(games_dir) if f.lower().endswith('.html')]
    except Exception:
        files = []
    return render_template('admin/games.html', games=files, active_page='admin_games')

@admin_bp.route('/reports')
@login_required
def reports():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    try:
        # Aggregate simple stats per therapist and patient
        therapists = User.query.filter_by(role='terapista').all()
        t_rows = []
        for t in therapists:
            count_appts = Appointment.query.filter_by(therapist_id=t.id).count()
            # Calculate average accuracy for sessions managed by this therapist
            # Using try/except within loop to prevent one bad record from crashing all
            try:
                avg_acc = db.session.query(func.avg(SessionMetrics.accurracy))\
                    .join(Appointment, SessionMetrics.session_id == Appointment.id)\
                    .filter(Appointment.therapist_id == t.id).scalar() or 0
            except Exception:
                avg_acc = 0
            t_rows.append({'name': t.username, 'email': t.email, 'sessions': count_appts, 'avg_accuracy': round(avg_acc,1)})
        
        patients = User.query.filter_by(role='jugador').all()
        p_rows = []
        for p in patients:
            plays = SessionMetrics.query.filter_by(user_id=p.id).count()
            try:
                acc = db.session.query(func.avg(SessionMetrics.accurracy)).filter_by(user_id=p.id).scalar() or 0
            except Exception:
                acc = 0
            p_rows.append({'name': p.username, 'email': p.email, 'plays': plays, 'avg_accuracy': round(acc,1)})
        
        # Financial Stats (Ticket 5)
        try:
            financials = payment_service.get_financial_summary()
        except Exception as e:
            current_app.logger.warning(f"Failed to load financials: {e}")
            financials = {
                'income_real': 0.0,
                'income_expected': 0.0, 
                'overdue_amount': 0.0,
                'overdue_users_count': 0,
                'expenses': 0.0,
                'net_profit': 0.0
            }
        
        return render_template('admin/reports.html', 
                               therapists=t_rows, 
                               patients=p_rows, 
                               financials=financials,
                               active_page='admin_reports')
    except Exception as e:
        current_app.logger.error(f"Error in admin/reports: {e}")
        import traceback
        traceback.print_exc()
        flash(f"Error generando reportes: {str(e)}", 'error')
        return render_template('admin/reports.html', therapists=[], patients=[], financials={'income_real':0,'income_expected':0,'overdue_amount':0,'overdue_users_count':0}, active_page='admin_reports')

@admin_bp.route('/reports/send-weekly-summary', methods=['POST'])
@login_required
def send_weekly_summary_manual():
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        from app.tasks import check_upcoming_payments
        # Use underlying app object
        app = current_app._get_current_object()
        
        # Run synchronous and FORCE send even if no alerts
        check_upcoming_payments(app, force=True)
        
        return jsonify({'success': True, 'message': 'Reporte semanal enviado al correo del administrador.'})
    except Exception as e:
        current_app.logger.error(f"Manual report error: {e}")
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/reports/export-payments')
@login_required
def export_payments_csv():
    if current_user.role != 'admin':
        return redirect(url_for('main.dashboard'))
    
    import csv
    from io import StringIO
    from flask import make_response
    
    # Get all payments or filtered by month? Ticket implies monthly but let's dump all for now or current month
    # "Listado de pagos del mes"
    today = datetime.utcnow().date()
    start_date = today.replace(day=1) # Start of this month
    
    payments = Payment.query.filter(Payment.date >= start_date).order_by(Payment.date.desc()).all()
    
    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(['ID', 'Paciente', 'Monto', 'Descuento', 'Metodo', 'Referencia', 'Fecha', 'Notas']) # Header
    
    for p in payments:
        patient_name = p.patient.username if p.patient else 'Unknown'
        cw.writerow([
            p.id, 
            patient_name, 
            p.amount, 
            p.discount, 
            p.method, 
            p.reference, 
            p.date.strftime('%Y-%m-%d %H:%M'),
            p.notes
        ])
        
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = f"attachment; filename=pagos_{today.strftime('%Y_%m')}.csv"
    output.headers["Content-type"] = "text/csv"
    return output


@admin_bp.route('/sedes')
@login_required
def sedes_page():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    return render_template('admin/sedes.html', active_page='admin_sedes')


@admin_bp.route('/expenses')
@login_required
def expenses():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    # Financial data
    financials = finance_service.get_therapist_financials()
    recent = finance_service.get_expenses() 
    
    return render_template('admin/expenses.html', 
                            therapist_financials=financials,
                            recent_expenses=recent,
                            current_date=datetime.now().strftime('%Y-%m-%d'),
                            active_page='admin_expenses')

@admin_bp.route('/expenses/create', methods=['POST'])
@login_required
def create_expense_route():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    data = request.form.to_dict()
    # Normalize therapist_id - if empty string, remove it so it's None or handle in service
    if not data.get('therapist_id'):
        data['therapist_id'] = None
    elif data.get('therapist_id') == '':
         data['therapist_id'] = None

    # Handle File Upload for Receipt
    if 'receipt' in request.files:
        file = request.files['receipt']
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            ext = os.path.splitext(filename)[1]
            unique_name = f"{uuid.uuid4().hex}{ext}"
            
            upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'receipts')
            if not os.path.exists(upload_dir):
                os.makedirs(upload_dir)
                
            file.save(os.path.join(upload_dir, unique_name))
            data['receipt_image_path'] = f"receipts/{unique_name}"

    success, res = finance_service.create_expense(data)
    
    if success:
        flash('Gasto/Pago registrado correctamente.', 'success')
    else:
        flash(f'Error al registrar: {res}', 'error')
        
    return redirect(url_for('admin.expenses'))

@admin_bp.route('/messages')
@login_required
def messages():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    therapists = User.query.filter_by(role='terapista', is_active=True).order_by(User.username.asc()).all()
    patients = User.query.filter_by(role='jugador', is_active=True).order_by(User.username.asc()).all()
    
    # NEW: Fetch contact messages
    contact_messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('admin/messages.html', therapists=therapists, patients=patients, active_page='admin_messages', contact_messages=contact_messages)


@admin_bp.route('/csp-reports')
@login_required
def csp_reports():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))

    # Filters
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 25))
    q_directive = request.args.get('directive')
    q_blocked = request.args.get('blocked_uri')
    q_since = request.args.get('since') # ISO date or empty

    query = CSPReport.query.order_by(CSPReport.received_at.desc())
    if q_directive:
        query = query.filter(CSPReport.violated_directive.ilike(f"%{q_directive}%"))
    if q_blocked:
        query = query.filter(CSPReport.blocked_uri.ilike(f"%{q_blocked}%"))
    if q_since:
        try:
            from datetime import datetime
            since_dt = datetime.fromisoformat(q_since)
            query = query.filter(CSPReport.received_at >= since_dt)
        except Exception:
            pass

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)

    return render_template('admin/csp_reports.html', pagination=pagination, active_page='admin_reports')


@admin_bp.route('/admin/api/tokens', methods=['GET', 'POST'])
@login_required
def admin_api_tokens():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        rotate = request.form.get('rotate') == '1'
        if rotate:
            rows = AdminAPIToken.query.filter_by(is_active=True).all()
            for r in rows:
                r.deactivate()
        # generate token
        token = secrets.token_urlsafe(32)
        token_hash = bcrypt.generate_password_hash(token).decode('utf-8')
        new = AdminAPIToken(token_hash=token_hash, is_active=True)
        db.session.add(new)
        db.session.commit()
        # show plaintext token once via flash (admins must copy it)
        flash(f'Nuevo token creado. Copia y guarda ahora: {token}', 'success')

    tokens = AdminAPIToken.query.order_by(AdminAPIToken.created_at.desc()).all()
    return render_template('admin/api_tokens.html', tokens=tokens, active_page='admin_reports')


@admin_bp.route('/admin/api/tokens/deactivate/<int:token_id>', methods=['POST'])
@login_required
def deactivate_admin_token(token_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'No autorizado'}), 403
    t = AdminAPIToken.query.get_or_404(token_id)
    t.deactivate()
    db.session.commit()
    flash('Token desactivado.', 'success')
    return redirect(url_for('admin.admin_api_tokens'))


@admin_bp.route('/admin/api/csp-reports')
def _admin_api_auth(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        # Allow session-based admin users
        if current_user and getattr(current_user, 'is_authenticated', False) and getattr(current_user, 'role', None) == 'admin':
            return f(*args, **kwargs)

        # Allow bearer token via ADMIN_API_TOKEN env var
        auth = request.headers.get('Authorization', '')
        if auth.startswith('Bearer '):
            token = auth.split(' ', 1)[1].strip()
            expected = os.getenv('ADMIN_API_TOKEN')
            if expected and token == expected:
                return f(*args, **kwargs)

            # Otherwise check active hashed tokens in DB
            try:
                token_rows = AdminAPIToken.query.filter_by(is_active=True).all()
                for row in token_rows:
                    if bcrypt.check_password_hash(row.token_hash, token):
                        return f(*args, **kwargs)
            except Exception:
                pass

        return jsonify({'error': 'No autorizado'}), 403
    return wrapper


@admin_bp.route('/api/csp-reports')
@_admin_api_auth
def api_csp_reports():

    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 25))
    q_directive = request.args.get('directive')
    q_blocked = request.args.get('blocked_uri')
    q_since = request.args.get('since')

    query = CSPReport.query.order_by(CSPReport.received_at.desc())
    if q_directive:
        query = query.filter(CSPReport.violated_directive.ilike(f"%{q_directive}%"))
    if q_blocked:
        query = query.filter(CSPReport.blocked_uri.ilike(f"%{q_blocked}%"))
    if q_since:
        try:
            from datetime import datetime
            since_dt = datetime.fromisoformat(q_since)
            query = query.filter(CSPReport.received_at >= since_dt)
        except Exception:
            pass

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    items = []
    for r in pagination.items:
        items.append({
            'id': r.id,
            'received_at': r.received_at.isoformat(),
            'document_uri': r.document_uri,
            'violated_directive': r.violated_directive,
            'blocked_uri': r.blocked_uri,
            'ip_address': r.ip_address,
            'user_id': r.user_id
        })

    return jsonify({
        'items': items,
        'page': pagination.page,
        'per_page': pagination.per_page,
        'total': pagination.total,
        'pages': pagination.pages
    })


@admin_bp.route('/csp-reports/export')
@_admin_api_auth
def export_csp_reports():
    # For non-UI API token auth, we cannot redirect; return 403 instead
    if not (current_user and getattr(current_user, 'is_authenticated', False) and getattr(current_user, 'role', None) == 'admin'):
        # If token auth used, allow continuing; _admin_api_auth already allowed or rejected.
        # For UI access, ensure we don't redirect to main when using token auth — token users should download CSV.
        # Continue and let _admin_api_auth have validated the request.
        pass

    q_directive = request.args.get('directive')
    q_blocked = request.args.get('blocked_uri')
    q_since = request.args.get('since')

    query = CSPReport.query.order_by(CSPReport.received_at.desc())
    if q_directive:
        query = query.filter(CSPReport.violated_directive.ilike(f"%{q_directive}%"))
    if q_blocked:
        query = query.filter(CSPReport.blocked_uri.ilike(f"%{q_blocked}%"))
    if q_since:
        try:
            from datetime import datetime
            since_dt = datetime.fromisoformat(q_since)
            query = query.filter(CSPReport.received_at >= since_dt)
        except Exception:
            pass

    reports = query.all()

    # Build CSV
    import csv
    from io import StringIO
    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(['id','received_at','document_uri','violated_directive','blocked_uri','ip_address','user_id'])
    for r in reports:
        cw.writerow([r.id, r.received_at.isoformat(), r.document_uri or '', r.violated_directive or '', r.blocked_uri or '', r.ip_address or '', r.user_id or ''])

    output = si.getvalue()
    from flask import make_response
    resp = make_response(output)
    resp.headers['Content-Type'] = 'text/csv'
    resp.headers['Content-Disposition'] = 'attachment; filename=csp_reports.csv'
    return resp

@admin_bp.route('/profile')
@login_required
def profile():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    return render_template('admin/profile.html', active_page='admin_dashboard')

@admin_bp.route('/payments')
@login_required
def payments():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    # Auto-check overdue stats on load
    deactivated = payment_service.check_and_deactivate_overdue()
    if deactivated > 0:
        flash(f'{deactivated} usuarios han sido desactivados por falta de pago.', 'warning')

    patients_status = payment_service.get_patients_payment_status()
    therapists = User.query.filter_by(role='terapista').all()
    sedes = Sede.query.all()
    payment_history = payment_service.get_payment_history()
    return render_template('admin/payments.html', patients=patients_status, therapists=therapists, sedes=sedes, payment_history=payment_history, active_page='admin_payments')

@admin_bp.route('/api/payment-info/<int:patient_id>')
@login_required
def get_payment_info(patient_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'No autorizado'}), 403
    
    info = payment_service.get_billing_info(patient_id)
    if not info:
        return jsonify({'error': 'Usuario no encontrado'}), 404
        
    return jsonify(info)

@admin_bp.route('/payments/register', methods=['POST'])
@login_required
def register_payment():
    if current_user.role != 'admin':
        return redirect(url_for('main.dashboard'))
    # Collect form data and validate
    discount_input = request.form.get('discount')
    if not discount_input or discount_input.strip() == '':
        discount_input = 0.0

    next_date_input = request.form.get('next_due_date')
    if not next_date_input or next_date_input.strip() == '':
         next_date_input = None
         
    form = {
        'patient_id': request.form.get('patient_id'),
        'amount': request.form.get('amount'),
        'discount': discount_input,
        'method': request.form.get('method'),
        'reference': request.form.get('reference'),
        'next_due_date': next_date_input
    }

    # Manual payment date extraction
    payment_date_str = request.form.get('payment_date')
    payment_date_obj = None
    if payment_date_str:
        try:
             payment_date_obj = datetime.strptime(payment_date_str, '%Y-%m-%d')
        except ValueError:
             pass 

    data, errors = validate_payment_register(form)
    if errors:
        flash('Errores en el formulario de pago: ' + json.dumps(errors), 'error')
        current_app.logger.debug(f"Payment register validation errors: {errors}")
        return redirect(url_for('admin.payments'))

    patient_id = data['patient_id']
    amount = data['amount']
    discount = data.get('discount', 0.0)
    method = data['method']
    reference = data.get('reference')
    next_due_date = data.get('next_due_date')
    
    # Handle File Upload
    receipt_path = None
    if 'receipt' in request.files:
        file = request.files['receipt']
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            # Generate unique name
            ext = os.path.splitext(filename)[1]
            unique_name = f"{uuid.uuid4().hex}{ext}"
            
            # Subfolder for receipts
            upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'receipts')
            if not os.path.exists(upload_dir):
                os.makedirs(upload_dir)
                
            file.save(os.path.join(upload_dir, unique_name))
            
            # Store relative path for template usage
            # Fix: Previously it was storing "uploads/receipts/...", but base UPLOAD_FOLDER is already instance/uploads
            # So the relative path from UPLOAD_FOLDER should be just "receipts/..."
            receipt_path = f"receipts/{unique_name}"

    try:
         discount_val = float(discount) if discount else 0.0
    except:
         discount_val = 0.0

    success, msg = payment_service.register_payment(patient_id, float(amount), method, reference, next_due_date, receipt_path, discount_val, payment_date=payment_date_obj)
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'error')
    
    return redirect(url_for('admin.payments'))

@admin_bp.route('/payments/history/<int:patient_id>')
@login_required
def payment_history(patient_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.dashboard'))
    
    patient = User.query.get_or_404(patient_id)
    # Get payments directly
    payments = Payment.query.filter_by(patient_id=patient_id).order_by(Payment.date.desc()).all()
    
    return render_template('admin/payment_history.html', patient=patient, payments=payments, active_page='admin_payments')

@admin_bp.route('/payments/settings', methods=['POST'])
@login_required
def update_payment_settings():
    if current_user.role != 'admin':
        return redirect(url_for('main.dashboard'))
        
    patient_id = request.form.get('patient_id')
    amount = request.form.get('payment_amount')
    due_date = request.form.get('payment_due_date')
    frequency = request.form.get('payment_plan')
    
    success, msg = payment_service.update_payment_settings(patient_id, amount, due_date, frequency)
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'error')
    
    return redirect(url_for('admin.payments'))

@admin_bp.route('/payments/delete/<int:payment_id>', methods=['POST'])
@login_required
def delete_payment(payment_id):
    if current_user.role != 'admin':
        return redirect(url_for('main.dashboard'))
    
    try:
        payment = Payment.query.get_or_404(payment_id)
        
        # Optional: Delete file if exists
        if payment.receipt_image_path:
            file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], payment.receipt_image_path)
            if os.path.exists(file_path):
                os.remove(file_path)
        
        db.session.delete(payment)
        db.session.commit()
        flash('Pago eliminado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el pago: {str(e)}', 'error')
        
    return redirect(request.referrer or url_for('admin.payments'))

@admin_bp.route('/analyze-receipt', methods=['POST'])
@login_required
def analyze_receipt():
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403

    if 'receipt' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['receipt']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    try:
        import google.generativeai as genai
        import json
        
        api_key = os.environ.get('GEMINI_API_KEY') or current_app.config.get('GEMINI_API_KEY')
        if not api_key:
             return jsonify({'error': 'Gemini API Key not configured'}), 500
             
        genai.configure(api_key=api_key)
        
        # Read file content directly into memory
        image_data = file.read()
        
        # Vision Model
        # Falling back to the generic 'gemini-1.5-flash' which should be free tier compatible.
        # Dynamically find a working model to avoid 404s
        available_models = [m.name for m in genai.list_models() if 'generateContent' in m.supported_generation_methods]
        
        # Priority list (free/fast models first)
        priorities = [
            'models/gemini-2.0-flash-lite',
            'models/gemini-flash-latest', 
            'models/gemini-1.5-flash',
            'models/gemini-pro-vision',
            'models/gemini-2.0-flash' 
        ]
        
        selected_model_name = None
        
        # Try to find a priority model in available list
        for priority in priorities:
            if priority in available_models:
                selected_model_name = priority
                break
        
        # If no priority model found, pick the first available one that is likely a vision model
        if not selected_model_name:
             for m in available_models:
                 if 'flash' in m or 'vision' in m:
                     selected_model_name = m
                     break
        
        # Last resort: just take the first one
        if not selected_model_name and available_models:
            selected_model_name = available_models[0]
            
        print(f"DEBUG: Selected Gemini Model: {selected_model_name}") 
        
        if not selected_model_name:
            return jsonify({'error': 'No available Gemini models found for this API Key'}), 500

        model = genai.GenerativeModel(selected_model_name)
        
        prompt = "Analyze this payment receipt. Extract in JSON: amount (number), date (YYYY-MM-DD), reference (string), method (transferencia/yape/efectivo/tarjeta). If field is missing return null."
        
        response = model.generate_content([
            {'mime_type': file.content_type or 'image/jpeg', 'data': image_data},
            prompt
        ])
        
        text = response.text
        if '```json' in text:
            text = text.split('```json')[1].split('```')[0]
        elif '```' in text:
             text = text.split('```')[1].split('```')[0]
             
        data = json.loads(text.strip())
        return jsonify(data)
        
    except Exception as e:
        print(f"ERROR in analyze_receipt: {str(e)}") # Log to server console
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/sessions')
@login_required
def sessions_calendar():
    if current_user.role != 'admin':
        flash('Acceso denegado.', 'error')
        return redirect(url_for('main.dashboard'))
    
    therapists = User.query.filter_by(role='terapista', is_active=True).order_by(User.username.asc()).all()
    # Fetch all active patients
    patients = User.query.filter_by(role='jugador', is_active=True).order_by(User.username.asc()).all()
    
    return render_template('admin/sessions.html', 
                           therapists=therapists, 
                           patients=patients, 
                           active_page='admin_sessions')

@admin_bp.route('/api/sessions')
@login_required
def get_sessions_api():
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
        
    try:
        start_str = request.args.get('start') 
        end_str = request.args.get('end')
        therapist_id = request.args.get('therapist_id')
        
        query = Appointment.query
        
        if start_str and len(start_str) > 5:
            try:
                # Handle ISO format including Z or offset
                simple_start = start_str.split('T')[0]
                start_dt = datetime.strptime(simple_start, '%Y-%m-%d')
                query = query.filter(Appointment.start_time >= start_dt)
            except Exception:
                pass # Fallback to no filter

        if end_str and len(end_str) > 5:
            try:
                simple_end = end_str.split('T')[0]
                end_dt = datetime.strptime(simple_end, '%Y-%m-%d') + timedelta(days=1)
                query = query.filter(Appointment.start_time <= end_dt)
            except Exception:
                pass

        if therapist_id and therapist_id != 'all' and therapist_id != 'undefined':
            try:
                tid = int(therapist_id)
                query = query.filter(Appointment.therapist_id == tid)
            except ValueError:
                pass
            
        appointments = query.all()
        
        events = []
        for app in appointments:
            try:
                color = '#3788d8' # Default Blue
                if app.status == 'completed': color = '#10b981' # Green
                elif app.status == 'cancelled': color = '#ef4444' # Red
                elif app.status == 'scheduled': color = '#3b82f6' # Blue
                
                p_name = '???'
                # Use getattr to prevent crash if relationship is broken
                if getattr(app, 'patient', None):
                    p_name = app.patient.username
                
                t_name = '???'
                if getattr(app, 'therapist', None):
                    t_name = app.therapist.username
                
                # Check times
                if not app.start_time:
                    continue

                evt = {
                    'id': app.id,
                    'title': app.title if app.title else f"{p_name} ({t_name})",
                    'start': app.start_time.isoformat(),
                    'end': app.end_time.isoformat() if app.end_time else None,
                    'backgroundColor': color,
                    'borderColor': color,
                    'extendedProps': {
                        'therapist_id': app.therapist_id,
                        'patient_id': app.patient_id,
                        'therapist': t_name,
                        'patient': p_name,
                        'status': app.status,
                        'notes': app.notes
                    }
                }
                events.append(evt)
            except Exception as e_inner:
                current_app.logger.error(f"Error packing event {app.id}: {e_inner}")
                continue
            
        return jsonify(events)
    except Exception as e:
        current_app.logger.error(f"API Sessions Error: {e}")
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/api/sessions/batch', methods=['POST'])
@login_required
def batch_create_sessions():
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
        
    data = request.json
    therapist_id = data.get('therapist_id')
    patient_id = data.get('patient_id')
    start_date_str = data.get('start_date') # YYYY-MM-DD
    start_time_str = data.get('start_time') # HH:MM
    end_time_str = data.get('end_time') # HH:MM
    days_of_week = data.get('days') # list of ints [0, 2, 4] (Mon, Wed, Fri)
    title_prefix = data.get('title_prefix')
    # "se hace por cada 4 semanas": Duration of the cycle
    cycle_weeks = int(data.get('weeks', 4)) 
    
    if not all([therapist_id, patient_id, start_date_str, start_time_str, end_time_str, days_of_week]):
        return jsonify({'error': 'Faltan datos requeridos'}), 400
        
    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        start_h, start_m = map(int, start_time_str.split(':'))
        end_h, end_m = map(int, end_time_str.split(':'))
        
        created_count = 0
        current_date_iter = start_date
        end_date_iter = start_date + timedelta(weeks=cycle_weeks)
        
        # Determine total sessions to happen in this block for numbering
        # e.g. "Sesión 1/12"
        # First pass: Count total sessions
        total_sessions = 0
        temp_date = start_date
        while temp_date < end_date_iter:
            if temp_date.weekday() in days_of_week:
                total_sessions += 1
            temp_date += timedelta(days=1)
            
        session_counter = 1
        
        while current_date_iter < end_date_iter:
            if current_date_iter.weekday() in days_of_week:
                # Set time
                session_start = current_date_iter.replace(hour=start_h, minute=start_m)
                session_end = current_date_iter.replace(hour=end_h, minute=end_m)
                
                # If end time < start time, assume it ends next day (rare but possible)
                if session_end < session_start:
                    session_end += timedelta(days=1)
                
                if title_prefix and title_prefix.strip():
                     title = f"{title_prefix} ({session_counter}/{total_sessions})"
                else:
                     title = f"Sesión {session_counter}/{total_sessions}"
                
                appt = Appointment(
                    therapist_id=therapist_id,
                    patient_id=patient_id,
                    title=title,
                    start_time=session_start,
                    end_time=session_end,
                    status='scheduled',
                    created_at=datetime.utcnow()
                )
                db.session.add(appt)
                created_count += 1
                session_counter += 1
            
            current_date_iter += timedelta(days=1)
            
        db.session.commit()
        return jsonify({'success': True, 'message': f'Se crearon {created_count} sesiones exitosamente.'})
        
    except Exception as e:
        db.session.rollback()
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@admin_bp.route('/api/sessions/<int:session_id>', methods=['PUT'])
@login_required
def update_session(session_id):
    if current_user.role != 'admin':
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.json
    appt = Appointment.query.get(session_id)
    if not appt:
        return jsonify({'error': 'Session not found'}), 404
        
    try:
        if 'title' in data:
            appt.title = data['title']
        
        # Only parse dates if provided
        if 'start_date' in data and 'start_time' in data:
            # Combine
            start_dt = datetime.strptime(f"{data['start_date']} {data['start_time']}", "%Y-%m-%d %H:%M")
            appt.start_time = start_dt
            
        if 'end_time' in data and data.get('start_date'):
            # Reconstruct end timestamp
            end_dt = datetime.strptime(f"{data['start_date']} {data['end_time']}", "%Y-%m-%d %H:%M")
            # Handle next day case for end time (though rare in simple edit)
            if end_dt < appt.start_time:
                end_dt += timedelta(days=1)
            appt.end_time = end_dt
            
        if 'notes' in data:
            appt.notes = data['notes']
            
        if 'status' in data:
            appt.status = data['status']
            
        db.session.commit()
        return jsonify({'success': True, 'message': 'Sesión actualizada'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
