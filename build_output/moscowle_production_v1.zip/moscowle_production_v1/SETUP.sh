#!/bin/bash
# Quick setup script for production deployment

echo "=================================================="
echo "🚀 MOSCOWLE IA MVP - QUICK SETUP"
echo "=================================================="

# Define paths
APP_DIR=$(pwd)
VENV_DIR="${APP_DIR}/venv"

echo "[1/5] Creating virtual environment..."
python3 -m venv "$VENV_DIR"

echo "[2/5] Activating virtual environment..."
source "$VENV_DIR/bin/activate"

echo "[3/5] Upgrading pip..."
pip install --upgrade pip setuptools wheel

echo "[4/5] Installing dependencies..."
pip install -r requirements.txt

echo "[5/5] Creating logs directory..."
mkdir -p "${APP_DIR}/logs"

echo ""
echo "✅ Setup completed!"
echo ""
echo "📝 Next steps:"
echo "1. Copy .env.example to .env"
echo "2. Update .env with your configuration"
echo "3. Configure Python App in cPanel"
echo "4. See DEPLOY_PRODUCTION_CPANEL.md for full instructions"
echo ""
